# Overview 

The goal of this assignment is for you to further practice writing software requirements. 

# Instructions: Part 1 

A new home security software project is being developed to support the door-to-door sales team. The team needs a system that can:

* List potential customers using publicly available data (e.g., number of rooms, presence of a garage).
* Help salespeople determine the most suitable security system for each customer using a questionnaire.
* Run on mobile devices with large screens.

Based on this description, create 10 high-level requirements for the sales system:

* 4 user functional requirements (what the system should do for users)
* 4 user non-functional requirements (how well the system should perform)
* 2 system requirements (technical or environmental constraints)

```
Write your requirements here!
```
User Functional
1. The system should display a list of potential customers.
2. The system should provide questions that salespeople could use with customers to get information on their security needs. 
3. The system shall recommend 1 or more security system packages based on the salespeople questions.
4. The system should allow the salespeople to review, save, or edit the customer information and recommedations whenever they visit again. 

User Non-Functional
1. The system should be usable on phones and tablets without zooming in 
2. The system should generate security system recommendations after a questionnaire completion.
3. The system shall have an easy-to-learn interface that a salesperson can complete a customer questionnaire within 15 minutes.
4. The system should be usable without the need of internet connectivity.

System
1. The system should be compatible with major most operating systems used by the salespeople. 
2. The system should store and encrpyt all customer data. 

# Instructions: Part 2

For each of the following high-level requirements, mark them as either user or system requirement. For user requirements, choose whether they are functional or non-functional requirements.

* librarians should be able to generate reports on book loans, returns, and inventory status *

[X] user, functional requirement

[ ] user, non-functional requirement

[ ] system requirement

* the library should offer self-service stations *

[ ] user, functional requirement

[ ] user, non-functional requirement

[X] system requirement

* users should get notifications about due dates and overdue books *

[X] user, functional requirement

[ ] user, non-functional requirement

[ ] system requirement

* users should be able to use the system through an intuitive and user-friendly interface that is easy to navigate *

[ ] user, functional requirement

[X] user, non-functional requirement

[ ] system requirement

* users should be able to search for for books by title, author, genre, or ISBN *

[X] user, functional requirement

[ ] user, non-functional requirement

[ ] system requirement

